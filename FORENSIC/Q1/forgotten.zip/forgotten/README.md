# Maze Runner

A terminal based maze game written in C.

## Build
```
make
```

## Run
```
./maze
```

## Status
Render fixed. Movement coming soon.
