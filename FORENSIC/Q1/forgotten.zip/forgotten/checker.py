import sys
import hashlib
import time
import os

MAGIC = [0x43, 0x79, 0x43, 0x30, 0x67]
TAIL  = [0x7B, 0x7D]

def _xor_validate(data, key=0x5A):
    return [b ^ key for b in data]

def _checksum(s):
    return hashlib.sha256(s.encode()).hexdigest()

def _entropy_check(s):
    seen = set()
    for c in s:
        seen.add(c)
    return len(seen)

def _header_verify(token):
    raw = [ord(c) for c in token[:5]]
    return raw == MAGIC

def _tail_verify(token):
    raw = [ord(c) for c in [token[5], token[-1]]]
    return raw == TAIL

def _segment_extract(token):
    start = token.index('{') + 1
    end   = token.index('}')
    return token[start:end]

def _phase_one(segment):
    _table = {
        ord('e'): '3',
        ord('o'): '0',
        ord('i'): '1',
    }
    buf = []
    for ch in segment:
        code = ord(ch)
        buf.append(_table[code] if code in _table else ch)
    return ''.join(buf)

def _phase_two(segment):
    pairs = [(segment[i], segment[i+1] if i+1 < len(segment) else '') for i in range(0, len(segment), 2)]
    return ''.join(a + b for a, b in pairs)

def _phase_three(segment):
    _xor_validate(list(segment.encode()), key=0x00)
    return segment

def _reconstruct(prefix, body, suffix):
    return prefix + '{' + body + '}'

def _integrity_check(result):
    h = _checksum(result)
    return len(h) == 64

def _display(result):
    bar = "-" * 40
    print(bar)
    print("[*] Running validation pipeline...")
    time.sleep(0.3)
    print("[*] Phase 1 complete")
    time.sleep(0.2)
    print("[*] Phase 2 complete")
    time.sleep(0.2)
    print("[*] Phase 3 complete")
    time.sleep(0.3)
    print("[*] Integrity check passed")
    print(bar)
    print(f"[+] Flag: {result}")
    print(bar)

def _fail():
    print("[-] Validation failed. Invalid key.")
    print("[-] Try harder.")
    sys.exit(1)

def run(token):
    token = token.strip()

    if not _header_verify(token):
        _fail()

    if not _tail_verify(token):
        _fail()

    if _entropy_check(token) < 5:
        _fail()

    try:
        segment = _segment_extract(token)
    except ValueError:
        _fail()

    p1 = _phase_one(segment)
    p2 = _phase_two(p1)
    p3 = _phase_three(p2)

    result = _reconstruct("CyC0g", p3, "")

    if not _integrity_check(result):
        _fail()

    _display(result)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 checker.py <key>")
        sys.exit(1)
    run(sys.argv[1])
