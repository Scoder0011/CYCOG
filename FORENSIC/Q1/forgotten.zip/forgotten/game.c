#include <stdio.h>
#include "game.h"

void init_game() {
    printf("Initializing game...\n");
}

void game_loop() {
    int running = 1;
    int frame = 0;
    while (running) {
        render();
        frame++;
        if (frame > 10) running = 0;
    }
}

void render() {
    printf("[ ] [ ] [ ]\n");
    printf("[ ] [X] [ ]\n");
    printf("[ ] [ ] [ ]\n");
}
