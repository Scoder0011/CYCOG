#include <stdio.h>
#include "game.h"

int main() {
    printf("Maze Runner v0.1\n");
    init_game();
    game_loop();
    return 0;
}

// TODO: never got around to finishing this
// maybe someday...
