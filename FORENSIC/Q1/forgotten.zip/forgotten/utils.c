#include <stdio.h>
#include <stdlib.h>

void clear_screen() {
    system("clear");
}

int random_int(int min, int max) {
    return min + rand() % (max - min + 1);
}
