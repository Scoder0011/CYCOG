#ifndef UTILS_H
#define UTILS_H

void clear_screen();
int random_int(int min, int max);

#endif
